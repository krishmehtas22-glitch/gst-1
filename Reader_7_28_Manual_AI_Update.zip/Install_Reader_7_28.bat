@echo off
setlocal
cd /d "%~dp0"
py "%~dp0Apply_Manual_AI_Reader_7_28.py"
echo.
pause
