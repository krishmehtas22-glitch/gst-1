READER 7.28 - MANUAL AI CONTROL

FIRST: Close the old app or press Stop AI and turn off Watch in version 7.27.

1. Extract this ZIP.
2. Copy all three files into F:\Downloads\dummy sales invoice, beside
   Invoice_Desktop.py and Common_Rules.
3. Double-click Install_Reader_7_28.bat. Check the printed target path.
4. Reopen using Open_Invoice_App.bat. Verify the title says Reader 7.28.

Opening, refreshing and watching only list PDFs. No automatic AI/OCR/PDF
analysis or XML generation. Select 1 or 100 files yourself, click Analyse
selected PDFs, and confirm. Client batch buttons also require confirmation.
Fresh attempts across providers are capped at your confirmed PDF count.
Saved successes are reused. Stop prevents further calls after the current one.

Import ALL, UQC, Tally transport and financial history remain unchanged.
Known source files are backed up. Unknown edits are preserved.
This updates Python source; an old frozen EXE needs a Windows rebuild.
