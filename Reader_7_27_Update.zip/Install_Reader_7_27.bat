@echo off
setlocal
cd /d "%~dp0"
py "%~dp0Apply_AI_First_Reader_7_27.py"
echo.
pause
