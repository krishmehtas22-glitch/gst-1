Reader 7.27 update - AI first, Python XML second

1. Close all invoice-reader windows.
2. Extract this ZIP.
3. Copy these three files into F:\Downloads\dummy sales invoice
   beside Invoice_Desktop.py and the Common_Rules folder.
4. Double-click Install_Reader_7_27.bat.
5. Check that it prints the exact main-folder Invoice_Desktop.py path.
6. Reopen the app using Open_Invoice_App.bat. Its title must say Reader 7.27.

This fixes the installer selecting a nested Automation copy instead of the
main-folder app. Code backups are automatic. Unknown edits are preserved.
Import ALL, UQC definitions, saved approvals and financial history are unchanged.
The installer sends no AI/Tally requests.

If you use a frozen EXE, that EXE needs a Windows rebuild. Use the Python launcher
to open the updated source.
