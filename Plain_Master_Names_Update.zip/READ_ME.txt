PLAIN PARTY AND INVENTORY NAMES - NAMING-ONLY PATCH

Close the app. Extract and copy these three files into
F:\Downloads\dummy sales invoice beside Invoice_Desktop.py and Common_Rules.
Double-click Install_Plain_Master_Names.bat, then Open_Invoice_App.bat.
Reader title/buttons stay as they are (7.29 or 7.30).
An old frozen EXE needs a Windows rebuild.

Double-click an invoice and Save changes to XML to regenerate the client's
XML from saved/local data, without new AI requests.
Ordinary party and stock names have no generated [batch hash] suffix.
Incompatible same-name units/GSTINs/HSN/tax definitions use readable details.
Amounts, quantity/rate, taxes, unit/UQC, dates, GUIDs and AI extraction stay the same.
Import ALL and actual inventory batch/godown allocations are unchanged.

Existing Tally masters and vouchers are not automatically renamed.
Review previously imported entries in Tally before importing regenerated XML.
No AI requests, XML generation or Tally import is sent by this installer.
Known sources are backed up and unknown local edits are preserved.
