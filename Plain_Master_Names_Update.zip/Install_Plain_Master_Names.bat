@echo off
setlocal
cd /d "%~dp0"
py "%~dp0Apply_Plain_Master_Names.py"
echo.
pause
