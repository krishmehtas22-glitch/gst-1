@echo off
setlocal
cd /d "%~dp0"
py "%~dp0Apply_Review_Reader_7_29.py"
echo.
pause
