READER 7.29 - SIMPLIFIED CONTROLS AND MANUAL XML SAVE

Close the app. Extract this ZIP and copy its three files into
F:\Downloads\dummy sales invoice beside Invoice_Desktop.py and Common_Rules.
Double-click Install_Reader_7_29.bat. Reopen Open_Invoice_App.bat.
Check the title says Reader 7.29. An old EXE needs a Windows rebuild.

Groq controls remain. Gemini/OpenRouter/GitHub/provider picker and the
Accept/change units, Recover processing lock, Confirm test PDF buttons are removed.
Backend AI extraction/prompt/fallback/cache behavior is preserved.
Double-click an invoice, edit fields/items/units and click Save changes
to XML. Python updates that client's Units, Masters and Sales XML without AI.
When Test invoices is on, saving confirms the PDF contains fictional data.
For real invoices, untick Test invoices.

Opening/refreshing/watching only lists PDFs. AI requires your explicit action
and count confirmation. Import ALL, UQC and XML writers remain unchanged.
Installer backs up known sources and refuses unknown local changes.
