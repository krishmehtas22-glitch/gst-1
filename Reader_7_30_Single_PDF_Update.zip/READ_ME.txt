READER 7.30 - EXPLICIT ONE-PDF AI BUTTON

Close the app. Extract this ZIP and copy all three files into
F:\Downloads\dummy sales invoice beside Invoice_Desktop.py and Common_Rules.
Double-click Install_Reader_7_30.bat. Open using Open_Invoice_App.bat.
Check the title says Reader 7.30. An old EXE needs a Windows rebuild.

Click the ONE PDF you want, then Analyse ONE PDF with Groq.
The confirmation names that PDF and caps new AI attempts at one.
Other PDFs receive no new AI requests. Saved reads/approvals are reused.
Analyse selected PDFs and Read client batch remain separate batch actions.

Python still prepares complete client XML from retained/local values.
The status separates new AI attempts from client XML voucher counts.
Startup/watching only list PDFs. Manual edits, AI extraction, XML writers,
UQC and Import ALL remain unchanged.
