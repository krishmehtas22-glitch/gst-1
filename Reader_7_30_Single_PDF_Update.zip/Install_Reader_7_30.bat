@echo off
setlocal
cd /d "%~dp0"
py "%~dp0Apply_Single_PDF_Reader_7_30.py"
echo.
pause
